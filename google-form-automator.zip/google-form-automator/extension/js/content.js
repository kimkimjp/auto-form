let isCapturing = false;
let formData = {};

function captureFormData() {
  console.log('Starting form data capture...');
  
  formData = {
    url: window.location.href,
    title: document.title,
    fields: [],
    timestamp: new Date().toISOString()
  };

  console.log('Capturing form:', formData.title);

  // Capture text inputs and textareas
  const textSelectors = [
    'input[type="text"]',
    'input[type="email"]', 
    'input[type="url"]',
    'input[type="number"]',
    'textarea',
    'input:not([type])'  // inputs without type attribute
  ];
  
  textSelectors.forEach(selector => {
    const inputs = document.querySelectorAll(selector);
    console.log(`Found ${inputs.length} inputs for selector: ${selector}`);
    
    inputs.forEach((input, index) => {
      if (input.value.trim() !== '') {
        const questionText = getQuestionText(input);
        console.log(`Capturing text input: "${questionText}" = "${input.value}"`);
        formData.fields.push({
          type: 'text',
          questionText: questionText,
          value: input.value,
          selector: generateSelector(input),
          index: index,
          originalSelector: selector
        });
      }
    });
  });

  // Capture radio buttons (only checked ones)
  const radioInputs = document.querySelectorAll('input[type="radio"]:checked');
  console.log(`Found ${radioInputs.length} checked radio buttons`);
  
  radioInputs.forEach((input, index) => {
    const questionText = getQuestionText(input);
    const label = getLabelText(input);
    console.log(`Capturing radio: "${questionText}" = "${label}"`);
    formData.fields.push({
      type: 'radio',
      questionText: questionText,
      value: label,
      selector: generateSelector(input),
      index: index
    });
  });

  // Capture checkboxes (only checked ones)
  const checkboxInputs = document.querySelectorAll('input[type="checkbox"]:checked');
  console.log(`Found ${checkboxInputs.length} checked checkboxes`);
  
  checkboxInputs.forEach((input, index) => {
    const questionText = getQuestionText(input);
    const label = getLabelText(input);
    console.log(`Capturing checkbox: "${questionText}" = "${label}"`);
    formData.fields.push({
      type: 'checkbox',
      questionText: questionText,
      value: label,
      selector: generateSelector(input),
      index: index
    });
  });

  // Capture select dropdowns
  const selects = document.querySelectorAll('select');
  console.log(`Found ${selects.length} select elements`);
  
  selects.forEach((select, index) => {
    if (select.value && select.value !== '') {
      const questionText = getQuestionText(select);
      const selectedOption = select.options[select.selectedIndex];
      const displayValue = selectedOption ? selectedOption.textContent : select.value;
      console.log(`Capturing select: "${questionText}" = "${displayValue}"`);
      formData.fields.push({
        type: 'select',
        questionText: questionText,
        value: select.value,
        displayValue: displayValue,
        selector: generateSelector(select),
        index: index
      });
    }
  });

  // Capture Google Forms specific elements
  captureGoogleFormSpecific();

  console.log(`Total fields captured: ${formData.fields.length}`);
  
  if (formData.fields.length === 0) {
    console.warn('No form fields were captured! This might indicate an issue.');
    showNotification('フォームに入力内容がないか、フォーム構造を認識できませんでした。');
  }

  return formData;
}

function captureGoogleFormSpecific() {
  // Capture Google Forms specific radio/checkbox groups
  const googleRadioGroups = document.querySelectorAll('[role="radiogroup"]');
  console.log(`Found ${googleRadioGroups.length} Google Forms radio groups`);
  
  googleRadioGroups.forEach((group, groupIndex) => {
    const selectedRadio = group.querySelector('[aria-checked="true"]');
    if (selectedRadio) {
      const questionText = getQuestionTextFromGroup(group);
      const value = selectedRadio.getAttribute('data-value') || selectedRadio.textContent.trim();
      console.log(`Capturing Google radio group: "${questionText}" = "${value}"`);
      formData.fields.push({
        type: 'google-radio',
        questionText: questionText,
        value: value,
        selector: generateSelectorForGoogleElement(selectedRadio),
        index: groupIndex
      });
    }
  });

  // Capture Google Forms checkboxes
  const googleCheckboxGroups = document.querySelectorAll('[role="group"]');
  console.log(`Found ${googleCheckboxGroups.length} Google Forms groups`);
  
  googleCheckboxGroups.forEach((group, groupIndex) => {
    const checkedBoxes = group.querySelectorAll('[aria-checked="true"]');
    if (checkedBoxes.length > 0) {
      const questionText = getQuestionTextFromGroup(group);
      checkedBoxes.forEach((checkbox, checkIndex) => {
        const value = checkbox.getAttribute('data-value') || checkbox.textContent.trim();
        console.log(`Capturing Google checkbox: "${questionText}" = "${value}"`);
        formData.fields.push({
          type: 'google-checkbox',
          questionText: questionText,
          value: value,
          selector: generateSelectorForGoogleElement(checkbox),
          index: `${groupIndex}-${checkIndex}`
        });
      });
    }
  });
}

function getQuestionText(element) {
  // Try multiple approaches to find the question text
  let questionText = '';
  
  // Method 1: Look for parent container with question
  let parent = element.closest('[role="listitem"], [role="group"]');
  if (!parent) parent = element.closest('.freebirdFormviewerViewItemsItemItem');
  if (!parent) parent = element.closest('div[jsmodel]');
  if (!parent) parent = element.closest('div');
  
  if (parent) {
    // Look for heading or title elements
    const selectors = [
      '[role="heading"]',
      '.freebirdFormviewerComponentsQuestionBaseTitle',
      '.freebirdFormviewerComponentsQuestionBaseHeader',
      'h1, h2, h3, h4, h5, h6',
      '.Qr7Oae'  // Google Forms question class
    ];
    
    for (const selector of selectors) {
      const questionElement = parent.querySelector(selector);
      if (questionElement && questionElement.textContent.trim()) {
        questionText = questionElement.textContent.trim();
        break;
      }
    }
  }
  
  // Method 2: Look for label associated with input
  if (!questionText) {
    const label = element.closest('label') || 
                 document.querySelector(`label[for="${element.id}"]`) ||
                 element.previousElementSibling;
    if (label && label.textContent.trim()) {
      questionText = label.textContent.trim();
    }
  }
  
  // Method 3: Look for aria-label or title
  if (!questionText) {
    questionText = element.getAttribute('aria-label') || 
                  element.getAttribute('title') || 
                  element.getAttribute('placeholder') || '';
  }
  
  // Method 4: Use nearby text content
  if (!questionText && parent) {
    const textNodes = parent.textContent.split('\n')
      .map(t => t.trim())
      .filter(t => t.length > 3 && t.length < 200);
    if (textNodes.length > 0) {
      questionText = textNodes[0];
    }
  }
  
  return questionText || 'Unknown Question';
}

function getQuestionTextFromGroup(group) {
  // For Google Forms groups, look for question text in parent containers
  const selectors = [
    '.freebirdFormviewerComponentsQuestionBaseTitle',
    '[role="heading"]',
    '.Qr7Oae',
    'h1, h2, h3, h4, h5, h6'
  ];
  
  // Check the group itself first
  for (const selector of selectors) {
    const questionElement = group.querySelector(selector);
    if (questionElement && questionElement.textContent.trim()) {
      return questionElement.textContent.trim();
    }
  }
  
  // Check parent containers
  let parent = group.parentElement;
  while (parent && parent !== document.body) {
    for (const selector of selectors) {
      const questionElement = parent.querySelector(selector);
      if (questionElement && questionElement.textContent.trim()) {
        return questionElement.textContent.trim();
      }
    }
    parent = parent.parentElement;
  }
  
  return 'Unknown Question';
}

function generateSelectorForGoogleElement(element) {
  const classes = Array.from(element.classList).join('.');
  const role = element.getAttribute('role');
  const dataValue = element.getAttribute('data-value');
  
  let selector = element.tagName.toLowerCase();
  if (role) selector += `[role="${role}"]`;
  if (dataValue) selector += `[data-value="${dataValue}"]`;
  if (classes) selector += `.${classes}`;
  
  return selector;
}

function getLabelText(input) {
  const label = input.closest('label');
  if (label) return label.textContent.trim();
  
  const sibling = input.nextElementSibling;
  if (sibling && sibling.tagName === 'LABEL') return sibling.textContent.trim();
  
  return input.value;
}

function generateSelector(element) {
  const tag = element.tagName.toLowerCase();
  const type = element.type || '';
  const name = element.name || '';
  const classes = Array.from(element.classList).join('.');
  
  let selector = tag;
  if (type) selector += `[type="${type}"]`;
  if (name) selector += `[name="${name}"]`;
  if (classes) selector += `.${classes}`;
  
  return selector;
}

function fillForm(savedData, autoSubmit = true) {
  console.log(`Starting to fill form: ${savedData.title}`);
  console.log(`Fields to fill: ${savedData.fields.length}`);
  
  savedData.fields.forEach((field, idx) => {
    console.log(`Filling field ${idx + 1}/${savedData.fields.length}:`, {
      type: field.type,
      questionText: field.questionText,
      value: field.value
    });
    
    try {
      switch (field.type) {
        case 'text':
          const textInputs = document.querySelectorAll('input[type="text"], textarea');
          if (textInputs[field.index]) {
            textInputs[field.index].value = field.value;
            textInputs[field.index].dispatchEvent(new Event('input', { bubbles: true }));
            console.log(`Filled text field at index ${field.index} with value: ${field.value}`);
          } else {
            console.warn(`Text input at index ${field.index} not found`);
          }
          break;
          
        case 'radio':
          const radioOptions = document.querySelectorAll('input[type="radio"]');
          radioOptions.forEach(radio => {
            const label = getLabelText(radio);
            if (label === field.value && getQuestionText(radio) === field.questionText) {
              radio.click();
            }
          });
          break;
          
        case 'checkbox':
          const checkboxOptions = document.querySelectorAll('input[type="checkbox"]');
          checkboxOptions.forEach(checkbox => {
            const label = getLabelText(checkbox);
            if (label === field.value && getQuestionText(checkbox) === field.questionText) {
              if (!checkbox.checked) checkbox.click();
            }
          });
          break;
          
        case 'select':
          const selects = document.querySelectorAll('select');
          if (selects[field.index]) {
            selects[field.index].value = field.value;
            selects[field.index].dispatchEvent(new Event('change', { bubbles: true }));
          }
          break;
          
        case 'google-radio':
          // Handle Google Forms radio groups
          const radioGroups = document.querySelectorAll('[role="radiogroup"]');
          if (radioGroups[field.index]) {
            const options = radioGroups[field.index].querySelectorAll('[role="radio"]');
            options.forEach(option => {
              const optionValue = option.getAttribute('data-value') || option.textContent.trim();
              if (optionValue === field.value) {
                option.click();
                console.log(`Clicked Google radio option: ${field.value}`);
              }
            });
          }
          break;
          
        case 'google-checkbox':
          // Handle Google Forms checkboxes
          const checkboxGroups = document.querySelectorAll('[role="group"]');
          checkboxGroups.forEach(group => {
            const options = group.querySelectorAll('[role="checkbox"]');
            options.forEach(option => {
              const optionValue = option.getAttribute('data-value') || option.textContent.trim();
              if (optionValue === field.value && getQuestionTextFromGroup(group) === field.questionText) {
                if (option.getAttribute('aria-checked') !== 'true') {
                  option.click();
                  console.log(`Clicked Google checkbox option: ${field.value}`);
                }
              }
            });
          });
          break;
      }
    } catch (error) {
      console.error('Error filling field:', field, error);
    }
  });
  
  // Wait a bit then submit the form if autoSubmit is enabled
  if (autoSubmit) {
    // Wait longer to ensure all fields are properly filled
    setTimeout(() => {
      submitForm();
    }, 2000);
  } else {
    showNotification('フォームに入力しました。手動で送信してください。');
  }
}

function submitForm() {
  console.log('Looking for submit button...');
  
  // Try different selectors for the submit button
  const submitSelectors = [
    // Primary selectors
    'div[role="button"] span:contains("送信")',
    'div[role="button"] span:contains("Submit")',
    'div[role="button"][aria-label*="送信"]',
    'div[role="button"][aria-label*="Submit"]',
    
    // Class-based selectors
    'div.freebirdFormviewerViewNavigationSubmitButton div[role="button"]',
    'div[jsname="M2UYVd"]',
    
    // Generic button selectors
    'div.uArJ5e.UQuaGc.Y5sE8d.VkkpIf.QvWxOd',
    'div.uArJ5e.UQuaGc.Y5sE8d.VkkpIf.NqnGTe'
  ];
  
  let submitButton = null;
  
  // First try: Look for buttons containing submit text
  const allButtons = document.querySelectorAll('div[role="button"]');
  for (const button of allButtons) {
    const buttonText = button.textContent.trim();
    if (buttonText === '送信' || buttonText === 'Submit' || 
        buttonText === '提出' || buttonText === 'Send') {
      submitButton = button;
      console.log('Found submit button by text:', buttonText);
      break;
    }
  }
  
  // Second try: Use selectors
  if (!submitButton) {
    for (const selector of submitSelectors) {
      try {
        if (selector.includes(':contains')) {
          // Handle :contains selector
          const match = selector.match(/(.+):contains\("(.+)"\)/);
          if (match) {
            const baseSelector = match[1].trim();
            const text = match[2];
            const elements = document.querySelectorAll(baseSelector);
            for (const el of elements) {
              if (el.textContent.includes(text)) {
                submitButton = el.closest('div[role="button"]') || el;
                if (submitButton) {
                  console.log('Found submit button by selector:', selector);
                  break;
                }
              }
            }
          }
        } else {
          submitButton = document.querySelector(selector);
          if (submitButton) {
            console.log('Found submit button by selector:', selector);
            break;
          }
        }
      } catch (e) {
        console.error('Error with selector:', selector, e);
      }
    }
  }
  
  // Third try: Look for the last button in the form
  if (!submitButton) {
    const formButtons = document.querySelectorAll('form div[role="button"]');
    if (formButtons.length > 0) {
      submitButton = formButtons[formButtons.length - 1];
      console.log('Using last button in form as submit button');
    }
  }
  
  if (submitButton) {
    console.log('Clicking submit button:', submitButton);
    
    // Try multiple click methods
    try {
      // Method 1: Direct click
      submitButton.click();
    } catch (e) {
      console.error('Direct click failed:', e);
      
      try {
        // Method 2: Dispatch click event
        submitButton.dispatchEvent(new MouseEvent('click', {
          bubbles: true,
          cancelable: true,
          view: window
        }));
      } catch (e2) {
        console.error('Dispatch click failed:', e2);
      }
    }
    
    // Show notification
    showNotification('フォームを送信しました');
  } else {
    console.error('Submit button not found after all attempts');
    showNotification('送信ボタンが見つかりません。手動で送信してください。');
  }
}

function showNotification(message) {
  const notification = document.createElement('div');
  notification.className = 'form-autofill-notification';
  notification.textContent = message;
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background-color: #333;
    color: white;
    padding: 12px 20px;
    border-radius: 4px;
    z-index: 10000;
    animation: slideIn 0.3s ease;
  `;
  
  document.body.appendChild(notification);
  
  setTimeout(() => {
    notification.remove();
  }, 3000);
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'captureForm') {
    const data = captureFormData();
    sendResponse({ success: true, data: data });
  } else if (request.action === 'fillForm') {
    console.log('Received fillForm request:', {
      formId: request.data.id,
      formTitle: request.data.title,
      fieldsCount: request.data.fields.length,
      autoSubmit: request.autoSubmit
    });
    fillForm(request.data, request.autoSubmit);
    sendResponse({ success: true });
  } else if (request.action === 'getFormInfo') {
    sendResponse({
      url: window.location.href,
      title: document.title
    });
  }
});

function addCaptureButton() {
  const button = document.createElement('button');
  button.textContent = '回答を記憶';
  button.style.cssText = `
    position: fixed;
    bottom: 20px;
    right: 20px;
    background-color: #1a73e8;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 14px;
    z-index: 10000;
    box-shadow: 0 2px 5px rgba(0,0,0,0.2);
  `;
  
  button.addEventListener('click', async () => {
    if (isCapturing) return;
    
    isCapturing = true;
    button.textContent = '記憶中...';
    button.disabled = true;
    
    try {
      const data = captureFormData();
      
      if (data.fields.length === 0) {
        button.textContent = '入力内容がありません';
        button.style.backgroundColor = '#ea4335';
        setTimeout(() => {
          button.textContent = '回答を記憶';
          button.style.backgroundColor = '#1a73e8';
          button.disabled = false;
          isCapturing = false;
        }, 3000);
        return;
      }
      
      // Ask for memo before saving
      const memo = prompt(`この回答にメモを追加しますか？\n（${data.fields.length}項目の回答を保存します）\n\n例：朝の出席確認用、会議参加用など`, '');
      
      // Add memo to data (empty string if user cancelled or left blank)
      data.memo = memo === null ? '' : memo.trim();
      
      chrome.runtime.sendMessage({
        action: 'saveFormData',
        data: data
      }, response => {
        if (response && response.success) {
          button.textContent = `保存完了！(${data.fields.length}項目)`;
          button.style.backgroundColor = '#34a853';
          const memoText = data.memo ? `（メモ：${data.memo}）` : '';
          showNotification(`フォームデータを保存しました（${data.fields.length}項目）${memoText}`);
        } else {
          button.textContent = '保存に失敗';
          button.style.backgroundColor = '#ea4335';
          showNotification('フォームデータの保存に失敗しました');
        }
        
        setTimeout(() => {
          button.textContent = '回答を記憶';
          button.style.backgroundColor = '#1a73e8';
          button.disabled = false;
          isCapturing = false;
        }, 3000);
      });
      
    } catch (error) {
      console.error('Error capturing form data:', error);
      button.textContent = 'エラーが発生';
      button.style.backgroundColor = '#ea4335';
      showNotification('フォームデータの取得中にエラーが発生しました');
      
      setTimeout(() => {
        button.textContent = '回答を記憶';
        button.style.backgroundColor = '#1a73e8';
        button.disabled = false;
        isCapturing = false;
      }, 3000);
    }
  });
  
  document.body.appendChild(button);
}

// Debug function to analyze form structure
function analyzeFormStructure() {
  console.log('=== Form Structure Analysis ===');
  
  // Basic form elements
  const forms = document.querySelectorAll('form');
  console.log(`Found ${forms.length} form elements`);
  
  const allInputs = document.querySelectorAll('input');
  const allTextareas = document.querySelectorAll('textarea');
  const allSelects = document.querySelectorAll('select');
  console.log(`Found ${allInputs.length} inputs, ${allTextareas.length} textareas, ${allSelects.length} selects`);
  
  // Google Forms specific elements
  const radioGroups = document.querySelectorAll('[role="radiogroup"]');
  const checkboxGroups = document.querySelectorAll('[role="group"]');
  const headings = document.querySelectorAll('[role="heading"]');
  
  console.log(`Found ${radioGroups.length} radio groups, ${checkboxGroups.length} checkbox groups, ${headings.length} headings`);
  
  // Show sample content
  if (headings.length > 0) {
    console.log('Sample questions:', Array.from(headings).slice(0, 3).map(h => h.textContent.trim()));
  }
  
  // Show current values
  const filledInputs = Array.from(allInputs).filter(input => input.value && input.value.trim() !== '');
  console.log(`Found ${filledInputs.length} inputs with values`);
  
  return {
    forms: forms.length,
    inputs: allInputs.length,
    filledInputs: filledInputs.length,
    radioGroups: radioGroups.length,
    checkboxGroups: checkboxGroups.length
  };
}

// Add debug button (only in development)
function addDebugButton() {
  const debugButton = document.createElement('button');
  debugButton.textContent = 'Debug';
  debugButton.style.cssText = `
    position: fixed;
    bottom: 20px;
    right: 150px;
    background-color: #666;
    color: white;
    border: none;
    padding: 5px 10px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 12px;
    z-index: 10000;
  `;
  
  debugButton.addEventListener('click', () => {
    analyzeFormStructure();
    captureFormData(); // This will log detailed capture info
  });
  
  document.body.appendChild(debugButton);
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    addCaptureButton();
    // Uncomment for debugging: addDebugButton();
  });
} else {
  addCaptureButton();
  // Uncomment for debugging: addDebugButton();
}