let scheduledForms = [];

chrome.runtime.onInstalled.addListener(() => {
  loadScheduledForms();
});

chrome.runtime.onStartup.addListener(() => {
  loadScheduledForms();
});

async function loadScheduledForms() {
  const result = await chrome.storage.local.get(['scheduledForms']);
  if (result.scheduledForms) {
    scheduledForms = result.scheduledForms;
    console.log('Loaded scheduled forms:', scheduledForms);
    setupAlarms();
  }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'saveFormData') {
    saveFormData(request.data).then(() => {
      sendResponse({ success: true });
    });
    return true;
  } else if (request.action === 'scheduleForm') {
    scheduleForm(request.formId, request.scheduledTime, request.isDaily, request.autoSubmit).then(() => {
      sendResponse({ success: true });
    });
    return true;
  } else if (request.action === 'getSavedForms') {
    getSavedForms().then(forms => {
      sendResponse({ forms: forms });
    });
    return true;
  } else if (request.action === 'getScheduledForms') {
    // Reload from storage to ensure we have the latest data
    chrome.storage.local.get(['scheduledForms'], (result) => {
      if (result.scheduledForms) {
        scheduledForms = result.scheduledForms;
      }
      sendResponse({ scheduledForms: scheduledForms });
    });
    return true;
  } else if (request.action === 'cancelSchedule') {
    cancelSchedule(request.scheduleId).then(() => {
      sendResponse({ success: true });
    });
    return true;
  } else if (request.action === 'updateFormMemo') {
    updateFormMemo(request.formId, request.memo).then(() => {
      sendResponse({ success: true });
    });
    return true;
  }
});

async function saveFormData(data) {
  const formId = generateFormId();
  const formEntry = {
    id: formId,
    url: data.url,
    title: data.title,
    fields: data.fields,
    timestamp: data.timestamp,
    memo: data.memo || '', // Save memo if provided
    savedAt: new Date().toISOString()
  };
  
  const result = await chrome.storage.local.get(['savedForms']);
  const savedForms = result.savedForms || [];
  savedForms.push(formEntry);
  
  await chrome.storage.local.set({ savedForms: savedForms });
  console.log('Form data saved with memo:', formId, data.memo);
  return formId;
}

async function getSavedForms() {
  const result = await chrome.storage.local.get(['savedForms']);
  return result.savedForms || [];
}

async function updateFormMemo(formId, memo) {
  const result = await chrome.storage.local.get(['savedForms']);
  const savedForms = result.savedForms || [];
  
  const formIndex = savedForms.findIndex(f => f.id === formId);
  if (formIndex !== -1) {
    savedForms[formIndex].memo = memo;
    savedForms[formIndex].memoUpdatedAt = new Date().toISOString();
    await chrome.storage.local.set({ savedForms: savedForms });
    console.log('Form memo updated:', formId, memo);
    return true;
  } else {
    console.error('Form not found for memo update:', formId);
    return false;
  }
}

async function scheduleForm(formId, scheduledTime, isDaily = false, autoSubmit = true) {
  const scheduleId = generateScheduleId();
  
  // Get the form data to include title in schedule
  const savedForms = await getSavedForms();
  const formData = savedForms.find(f => f.id === formId);
  
  const schedule = {
    id: scheduleId,
    formId: formId,
    formTitle: formData ? formData.title : 'Unknown Form',
    scheduledTime: scheduledTime,
    isDaily: isDaily,
    autoSubmit: autoSubmit,
    originalTime: scheduledTime,
    status: 'pending'
  };
  
  scheduledForms.push(schedule);
  await chrome.storage.local.set({ scheduledForms: scheduledForms });
  
  let alarmTime;
  if (isDaily) {
    alarmTime = getRandomizedTime(scheduledTime);
  } else {
    alarmTime = new Date(scheduledTime).getTime();
  }
  
  console.log('Creating alarm:', {
    scheduleId: scheduleId,
    formId: formId,
    formTitle: schedule.formTitle,
    alarmTime: new Date(alarmTime).toLocaleString(),
    isDaily: isDaily
  });
  
  chrome.alarms.create(scheduleId, { when: alarmTime });
  
  // Verify alarm was created
  chrome.alarms.get(scheduleId, (alarm) => {
    if (alarm) {
      console.log('Alarm created successfully:', alarm);
    } else {
      console.error('Failed to create alarm');
    }
  });
  
  return scheduleId;
}

function getRandomizedTime(baseTime) {
  const base = new Date(baseTime);
  const randomMinutes = Math.floor(Math.random() * 61) - 30; // -30 to +30 minutes
  base.setMinutes(base.getMinutes() + randomMinutes);
  
  // If the randomized time is in the past, schedule for the next day
  if (base.getTime() <= Date.now()) {
    base.setDate(base.getDate() + 1);
  }
  
  return base.getTime();
}

async function cancelSchedule(scheduleId) {
  scheduledForms = scheduledForms.filter(s => s.id !== scheduleId);
  await chrome.storage.local.set({ scheduledForms: scheduledForms });
  chrome.alarms.clear(scheduleId);
}

function setupAlarms() {
  console.log('Setting up alarms for scheduled forms...');
  scheduledForms.forEach(schedule => {
    if (schedule.status === 'pending' || schedule.isDaily) {
      let alarmTime;
      if (schedule.isDaily) {
        // For daily schedules, calculate next execution time
        alarmTime = getRandomizedTime(schedule.originalTime || schedule.scheduledTime);
      } else {
        alarmTime = new Date(schedule.scheduledTime).getTime();
      }
      
      if (alarmTime > Date.now()) {
        console.log('Creating alarm for schedule:', schedule.id, 'at', new Date(alarmTime).toLocaleString());
        chrome.alarms.create(schedule.id, { when: alarmTime });
      } else if (schedule.isDaily) {
        // If daily schedule time has passed today, schedule for tomorrow
        const tomorrow = new Date(schedule.originalTime || schedule.scheduledTime);
        tomorrow.setDate(tomorrow.getDate() + 1);
        alarmTime = getRandomizedTime(tomorrow);
        console.log('Creating alarm for tomorrow:', schedule.id, 'at', new Date(alarmTime).toLocaleString());
        chrome.alarms.create(schedule.id, { when: alarmTime });
      }
    }
  });
  
  // List all alarms for debugging
  chrome.alarms.getAll((alarms) => {
    console.log('All active alarms:', alarms);
  });
}

// Queue to handle multiple alarms
let executionQueue = [];
let isExecuting = false;

chrome.alarms.onAlarm.addListener(async (alarm) => {
  console.log('Alarm triggered:', alarm.name, 'at', new Date().toLocaleString());
  
  // Reload schedules from storage to ensure we have the latest data
  const result = await chrome.storage.local.get(['scheduledForms']);
  if (result.scheduledForms) {
    scheduledForms = result.scheduledForms;
  }
  
  const schedule = scheduledForms.find(s => s.id === alarm.name);
  if (schedule) {
    console.log('Found schedule:', schedule);
    // Add to queue instead of executing immediately
    executionQueue.push(schedule);
    processExecutionQueue();
  } else {
    console.log('Schedule not found for alarm:', alarm.name);
  }
});

async function processExecutionQueue() {
  if (isExecuting || executionQueue.length === 0) {
    return;
  }
  
  isExecuting = true;
  
  while (executionQueue.length > 0) {
    const schedule = executionQueue.shift();
    console.log('Processing schedule from queue:', schedule.id);
    
    try {
      await executeScheduledForm(schedule);
      // Wait between executions to avoid conflicts
      await new Promise(resolve => setTimeout(resolve, 5000));
    } catch (error) {
      console.error('Error executing schedule:', error);
    }
  }
  
  isExecuting = false;
}

async function executeScheduledForm(schedule) {
  console.log('Executing scheduled form:', {
    scheduleId: schedule.id,
    formId: schedule.formId,
    formTitle: schedule.formTitle
  });
  
  // Show notification
  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'images/icon48.png',
    title: 'Google Form 自動入力',
    message: `「${schedule.formTitle || 'フォーム'}」の自動入力を開始します...`
  });
  
  // Get fresh form data from storage to ensure we have the correct data
  const savedForms = await getSavedForms();
  const form = savedForms.find(f => f.id === schedule.formId);
  
  if (!form) {
    console.error('Form not found for schedule:', schedule);
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'images/icon48.png',
      title: 'エラー',
      message: 'フォームデータが見つかりません'
    });
    return;
  }
  
  console.log('Found form data:', {
    formId: form.id,
    title: form.title,
    fieldsCount: form.fields.length
  });
  
  try {
    // Check if a tab with the form URL is already open
    const existingTabs = await chrome.tabs.query({ url: form.url });
    
    let targetTab;
    if (existingTabs.length > 0) {
      // Close existing tabs to avoid confusion
      for (const tab of existingTabs) {
        await chrome.tabs.remove(tab.id);
      }
    }
    
    // Always create a new tab for each scheduled form
    targetTab = await chrome.tabs.create({ url: form.url });
    console.log('Created new tab:', targetTab.id, 'for form:', form.title);
    
    // Wait for tab to load
    await new Promise(resolve => {
      chrome.tabs.onUpdated.addListener(function listener(tabId, changeInfo) {
        if (tabId === targetTab.id && changeInfo.status === 'complete') {
          chrome.tabs.onUpdated.removeListener(listener);
          resolve();
        }
      });
    });
    
    // Wait a bit more for form to fully render
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // Fill the form with the specific form data
    console.log('Filling form in tab:', targetTab.id, 'with form data:', form.id, 'autoSubmit:', schedule.autoSubmit);
    await fillFormInTab(targetTab.id, form, schedule.autoSubmit !== false);
      
    // Show success notification
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'images/icon48.png',
      title: 'Google Form 自動入力',
      message: `「${form.title}」を${schedule.autoSubmit !== false ? '自動送信しました' : '入力しました'}`
    });
      
  } catch (error) {
    console.error('Error executing scheduled form:', error);
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'images/icon48.png',
      title: 'エラー',
      message: `「${form.title}」の自動入力に失敗しました`
    });
  }
    
    // Update schedule status and save to storage
    if (schedule.isDaily) {
      // Schedule next day's execution
      const nextDay = new Date(schedule.originalTime);
      const today = new Date();
      
      // Calculate days difference to ensure we're scheduling for tomorrow
      const daysDiff = Math.floor((today - new Date(schedule.originalTime)) / (1000 * 60 * 60 * 24));
      nextDay.setDate(nextDay.getDate() + daysDiff + 1);
      
      // Update the schedule with new time
      schedule.scheduledTime = nextDay.toISOString();
      schedule.lastExecuted = new Date().toISOString();
      
      // Update in-memory array
      const scheduleIndex = scheduledForms.findIndex(s => s.id === schedule.id);
      if (scheduleIndex !== -1) {
        scheduledForms[scheduleIndex] = schedule;
      }
      
      // Save to storage
      await chrome.storage.local.set({ scheduledForms: scheduledForms });
      
      // Create new alarm for next day with randomized time
      const randomizedTime = getRandomizedTime(nextDay);
      console.log('Scheduling next execution for:', new Date(randomizedTime).toLocaleString());
      chrome.alarms.create(schedule.id, { when: randomizedTime });
    } else {
      // Mark as completed
      schedule.status = 'completed';
      schedule.lastExecuted = new Date().toISOString();
      
      // Update in-memory array
      const scheduleIndex = scheduledForms.findIndex(s => s.id === schedule.id);
      if (scheduleIndex !== -1) {
        scheduledForms[scheduleIndex] = schedule;
      }
      
      // Save to storage
      await chrome.storage.local.set({ scheduledForms: scheduledForms });
    }
}

async function fillFormInTab(tabId, formData, autoSubmit = true) {
  try {
    await chrome.tabs.sendMessage(tabId, {
      action: 'fillForm',
      data: formData,
      autoSubmit: autoSubmit
    });
  } catch (error) {
    console.error('Error filling form:', error);
  }
}

function generateFormId() {
  return 'form_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

function generateScheduleId() {
  return 'schedule_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}