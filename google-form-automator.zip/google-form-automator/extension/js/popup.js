let currentFormId = null;
let currentEditingMemoId = null;

document.addEventListener('DOMContentLoaded', () => {
  loadSavedForms();
  loadScheduledForms();
  
  document.querySelectorAll('.tab-button').forEach(button => {
    button.addEventListener('click', (e) => {
      const tabName = e.target.dataset.tab;
      switchTab(tabName);
    });
  });
  
  document.getElementById('schedule-form').addEventListener('submit', handleScheduleSubmit);
  document.getElementById('cancel-schedule').addEventListener('click', closeScheduleModal);
  
  document.getElementById('memo-form').addEventListener('submit', handleMemoSubmit);
  document.getElementById('cancel-memo').addEventListener('click', closeMemoModal);
});

function switchTab(tabName) {
  document.querySelectorAll('.tab-button').forEach(btn => {
    btn.classList.remove('active');
  });
  document.querySelectorAll('.tab-content').forEach(content => {
    content.style.display = 'none';
  });
  
  document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
  document.getElementById(`${tabName}-tab`).style.display = 'block';
}

async function loadSavedForms() {
  chrome.runtime.sendMessage({ action: 'getSavedForms' }, (response) => {
    const forms = response.forms;
    const listElement = document.getElementById('saved-forms-list');
    
    if (forms.length === 0) {
      listElement.innerHTML = '<p class="empty-message">保存された回答はありません</p>';
      return;
    }
    
    listElement.innerHTML = forms.map(form => `
      <div class="form-item" data-form-id="${form.id}">
        <div class="form-info">
          <h4>${form.title}</h4>
          ${form.memo ? `<p class="form-memo"><strong>メモ:</strong> ${form.memo}</p>` : ''}
          <p class="form-url">${new URL(form.url).hostname}</p>
          <p class="form-date">保存日時: ${new Date(form.savedAt).toLocaleString('ja-JP')}</p>
          <p class="form-fields">回答数: ${form.fields.length}項目</p>
        </div>
        <div class="form-actions">
          <button class="btn btn-small btn-info memo-btn" data-form-id="${form.id}">
            ${form.memo ? 'メモ編集' : 'メモ追加'}
          </button>
          <button class="btn btn-small btn-primary schedule-btn" data-form-id="${form.id}">
            スケジュール
          </button>
          <button class="btn btn-small btn-secondary fill-now-btn" data-form-id="${form.id}">
            今すぐ入力
          </button>
          <button class="btn btn-small btn-danger delete-btn" data-form-id="${form.id}">
            削除
          </button>
        </div>
      </div>
    `).join('');
    
    // Add event listeners
    document.querySelectorAll('.memo-btn').forEach(btn => {
      btn.addEventListener('click', (e) => editMemo(e.target.dataset.formId));
    });
    document.querySelectorAll('.schedule-btn').forEach(btn => {
      btn.addEventListener('click', (e) => scheduleForm(e.target.dataset.formId));
    });
    document.querySelectorAll('.fill-now-btn').forEach(btn => {
      btn.addEventListener('click', (e) => fillFormNow(e.target.dataset.formId));
    });
    document.querySelectorAll('.delete-btn').forEach(btn => {
      btn.addEventListener('click', (e) => deleteForm(e.target.dataset.formId));
    });
  });
}

async function loadScheduledForms() {
  chrome.runtime.sendMessage({ action: 'getScheduledForms' }, async (response) => {
    const scheduledForms = response.scheduledForms;
    const listElement = document.getElementById('scheduled-forms-list');
    
    if (scheduledForms.length === 0) {
      listElement.innerHTML = '<p class="empty-message">スケジュールされた入力はありません</p>';
      return;
    }
    
    const forms = await new Promise(resolve => {
      chrome.runtime.sendMessage({ action: 'getSavedForms' }, (response) => {
        resolve(response.forms);
      });
    });
    
    listElement.innerHTML = scheduledForms.map(schedule => {
      const form = forms.find(f => f.id === schedule.formId);
      if (!form) return '';
      
      const statusClass = schedule.status === 'completed' ? 'completed' : 'pending';
      const statusText = schedule.status === 'completed' ? '完了' : '予定';
      const isDailyText = schedule.isDaily ? ' (毎日)' : '';
      const lastExecutedText = schedule.lastExecuted ? 
        `<p class="schedule-last">最終実行: ${new Date(schedule.lastExecuted).toLocaleString('ja-JP')}</p>` : '';
      
      return `
        <div class="schedule-item ${statusClass}" data-schedule-id="${schedule.id}">
          <div class="schedule-info">
            <h4>${form.title}${isDailyText}</h4>
            <p class="schedule-form-id">フォームID: ${schedule.formId}</p>
            <p class="schedule-time">実行時刻: ${new Date(schedule.originalTime || schedule.scheduledTime).toLocaleTimeString('ja-JP', { hour: '2-digit', minute: '2-digit' })}${schedule.isDaily ? ' ±30分' : ''}</p>
            <p class="schedule-status">状態: ${statusText}</p>
            ${lastExecutedText}
          </div>
          <div class="schedule-actions">
            ${schedule.status === 'pending' || schedule.isDaily ? `
              <button class="btn btn-small btn-danger cancel-schedule-btn" data-schedule-id="${schedule.id}">
                キャンセル
              </button>
            ` : ''}
          </div>
        </div>
      `;
    }).join('');
    
    // Add event listeners for cancel buttons
    document.querySelectorAll('.cancel-schedule-btn').forEach(btn => {
      btn.addEventListener('click', (e) => cancelSchedule(e.target.dataset.scheduleId));
    });
  });
}

function scheduleForm(formId) {
  currentFormId = formId;
  document.getElementById('schedule-modal').style.display = 'flex';
  
  const now = new Date();
  now.setMinutes(now.getMinutes() + 5);
  document.getElementById('schedule-date').value = now.toISOString().split('T')[0];
  document.getElementById('schedule-time').value = now.toTimeString().slice(0, 5);
}

async function fillFormNow(formId) {
  chrome.runtime.sendMessage({ action: 'getSavedForms' }, async (response) => {
    const form = response.forms.find(f => f.id === formId);
    if (form) {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      
      if (tabs[0].url.includes('docs.google.com/forms')) {
        chrome.tabs.sendMessage(tabs[0].id, {
          action: 'fillForm',
          data: form
        });
        window.close();
      } else {
        chrome.tabs.create({ url: form.url }, (tab) => {
          chrome.tabs.onUpdated.addListener(function listener(tabId, changeInfo) {
            if (tabId === tab.id && changeInfo.status === 'complete') {
              chrome.tabs.onUpdated.removeListener(listener);
              setTimeout(() => {
                chrome.tabs.sendMessage(tab.id, {
                  action: 'fillForm',
                  data: form
                });
              }, 2000);
            }
          });
        });
      }
    }
  });
}

async function deleteForm(formId) {
  if (confirm('この回答を削除しますか？')) {
    chrome.storage.local.get(['savedForms'], (result) => {
      const forms = result.savedForms || [];
      const updatedForms = forms.filter(f => f.id !== formId);
      chrome.storage.local.set({ savedForms: updatedForms }, () => {
        loadSavedForms();
      });
    });
  }
}

function cancelSchedule(scheduleId) {
  if (confirm('このスケジュールをキャンセルしますか？')) {
    chrome.runtime.sendMessage({ 
      action: 'cancelSchedule', 
      scheduleId: scheduleId 
    }, () => {
      loadScheduledForms();
    });
  }
}

function handleScheduleSubmit(e) {
  e.preventDefault();
  
  const date = document.getElementById('schedule-date').value;
  const time = document.getElementById('schedule-time').value;
  const isDaily = document.getElementById('daily-repeat').checked;
  const autoSubmit = document.getElementById('auto-submit').checked;
  const scheduledTime = new Date(`${date}T${time}`);
  
  if (scheduledTime <= new Date() && !isDaily) {
    alert('過去の時刻は指定できません');
    return;
  }
  
  chrome.runtime.sendMessage({
    action: 'scheduleForm',
    formId: currentFormId,
    scheduledTime: scheduledTime.toISOString(),
    isDaily: isDaily,
    autoSubmit: autoSubmit
  }, () => {
    closeScheduleModal();
    loadScheduledForms();
    switchTab('scheduled');
  });
}

function closeScheduleModal() {
  document.getElementById('schedule-modal').style.display = 'none';
  document.getElementById('daily-repeat').checked = false;
  document.getElementById('auto-submit').checked = true;
  currentFormId = null;
}

function editMemo(formId) {
  chrome.runtime.sendMessage({ action: 'getSavedForms' }, (response) => {
    const form = response.forms.find(f => f.id === formId);
    if (form) {
      currentEditingMemoId = formId;
      document.getElementById('memo-modal-title').textContent = form.memo ? 'メモを編集' : 'メモを追加';
      document.getElementById('memo-input').value = form.memo || '';
      document.getElementById('memo-modal').style.display = 'flex';
    }
  });
}

function closeMemoModal() {
  document.getElementById('memo-modal').style.display = 'none';
  document.getElementById('memo-input').value = '';
  currentEditingMemoId = null;
}

function handleMemoSubmit(e) {
  e.preventDefault();
  
  const memo = document.getElementById('memo-input').value.trim();
  
  if (!currentEditingMemoId) {
    alert('エラー: 編集対象のフォームが選択されていません');
    return;
  }
  
  chrome.runtime.sendMessage({
    action: 'updateFormMemo',
    formId: currentEditingMemoId,
    memo: memo
  }, (response) => {
    if (response && response.success) {
      closeMemoModal();
      loadSavedForms(); // Reload to show updated memo
    } else {
      alert('メモの保存に失敗しました');
    }
  });
}